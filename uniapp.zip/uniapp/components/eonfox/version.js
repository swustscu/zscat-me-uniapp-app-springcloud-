// 版本控制文件
	var version='0.0.12';
	export default  version;